(function () {
  if (window.__ankerProfileMounted) return;
  window.__ankerProfileMounted = true;

  function detectDegree() {
    const badges = document.querySelectorAll('.dist-value, [class*="dist-value"], [class*="distance-badge"]');
    for (const b of badges) {
      const t = (b.textContent || "").trim();
      if (/\b1st\b/.test(t)) return 1;
      if (/\b2nd\b/.test(t)) return 2;
      if (/\b3rd\b/.test(t)) return 3;
    }
    return undefined;
  }

  function detectMutuals() {
    const out = [];
    const anchor = Array.from(document.querySelectorAll("a")).find(
      (a) => /mutual connection/i.test(a.textContent || "")
    );
    if (!anchor) return out;
    const text = (anchor.textContent || "").replace(/\s+/g, " ").trim();
    const names = text.replace(/(?:,? and \d+ other.*|are mutual connections.*|\d+ mutual connections?.*)/i, "").trim();
    if (names) {
      for (const raw of names.split(/,| and /)) {
        const name = raw.trim();
        if (name && name.length > 2 && !/mutual/i.test(name)) out.push({ name });
      }
    }
    return out;
  }

  function makeButton() {
    const wrap = document.createElement("div");
    wrap.style.cssText = "position:fixed;top:76px;right:16px;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:280px;";
    const btn = document.createElement("button");
    btn.textContent = "Send to Anker";
    btn.style.cssText = "padding:10px 14px;border:none;border-radius:999px;cursor:pointer;background:#0a66c2;color:#fff;font-weight:600;font-size:13px;box-shadow:0 0 0 1px #0a66c233,0 6px 16px rgba(0,0,0,.18);";
    const msg = document.createElement("div");
    msg.style.cssText = "margin-top:8px;padding:8px 10px;border-radius:8px;background:#fff;color:#111;box-shadow:0 6px 24px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.06);font-size:12px;line-height:1.4;display:none;";
    wrap.appendChild(btn); wrap.appendChild(msg);
    document.body.appendChild(wrap);

    btn.onclick = async () => {
      const orig = btn.textContent;
      btn.textContent = "Sending…"; btn.disabled = true;
      msg.style.display = "block"; msg.textContent = "Capturing page HTML…";
      try {
        const html = document.documentElement.outerHTML;
        const url = window.location.href;
        const degree = detectDegree();
        const res = await chrome.runtime.sendMessage({ type: "ingest", url, html, degree });
        if (res?.error) throw new Error(res.error);
        const mutuals = detectMutuals();
        if (mutuals.length) chrome.runtime.sendMessage({ type: "syncMutuals", personUrl: url, mutuals }).catch(() => {});
        if (res?.ok === false && res?.reason === "no_match") {
          btn.textContent = "No match"; btn.style.background = "#f59e0b"; btn.style.color = "#1f1300";
          msg.textContent = res.hint || "No CRM row matches this profile yet.";
        } else if (res?.ok) {
          btn.textContent = "Saved to Anker"; btn.style.background = "#16a34a";
          const who = [res.extracted?.fullName, res.extracted?.title, res.extracted?.firm].filter(Boolean).join(" · ");
          msg.textContent = (who || res.summary || "Captured.") + (mutuals.length ? ` · ${mutuals.length} mutual${mutuals.length > 1 ? "s" : ""} recorded` : "");
        } else { throw new Error("Unexpected response."); }
      } catch (e) {
        btn.textContent = "Retry"; btn.style.background = "#dc2626";
        msg.textContent = e?.message || "Capture failed.";
      } finally { btn.disabled = false; setTimeout(() => { btn.textContent = orig; btn.style.background = "#0a66c2"; btn.style.color = "#fff"; }, 4000); }
    };
  }
  makeButton();
})();
