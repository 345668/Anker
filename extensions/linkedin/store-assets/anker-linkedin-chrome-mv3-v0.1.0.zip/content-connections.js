(function () {
  if (window.__ankerConnMounted) return;
  window.__ankerConnMounted = true;

  const BATCH_SIZE = 50;
  const SCROLL_PAUSE_MS = 900;
  const MAX_PASSES = 30;

  function parseDegreeBadge(scope) {
    const els = scope.querySelectorAll('[class*="dist-value"], .entity-result__badge-text, .distance-badge, [class*="badge"]');
    for (const n of els) {
      const t = (n.textContent || "").trim();
      if (/\b1st\b/.test(t)) return 1;
      if (/\b2nd\b/.test(t)) return 2;
      if (/\b3rd\b/.test(t)) return 3;
    }
    return undefined;
  }

  function extractCards() {
    const anchors = Array.from(document.querySelectorAll('a[href*="/in/"]'));
    const seen = new Set(); const out = [];
    for (const a of anchors) {
      const href = a.href.split("?")[0].split("#")[0];
      const m = href.match(/\/in\/([^/]+)/); if (!m) continue;
      const slug = decodeURIComponent(m[1]); if (seen.has(slug)) continue; seen.add(slug);
      let card = a; for (let d = 0; d < 8 && card; d++) {
        if (card.matches?.('li, [data-view-name="connections-list-item"], .mn-connection-card, .artdeco-list__item, .entity-result')) break;
        card = card.parentElement;
      }
      const scope = card || a;
      const nameEl = a.querySelector('[aria-hidden="true"]') || a;
      const name = (nameEl.textContent || "").replace(/\s+/g, " ").trim();
      if (!name) continue;
      const cands = Array.from(scope.querySelectorAll('p, .t-14, [class*="occupation"], [class*="subline"], [class*="headline"]'));
      let headline = null; for (const el of cands) {
        const t = (el.textContent || "").replace(/\s+/g, " ").trim();
        if (!t || t === name || /^Connected /i.test(t) || /^Message$/i.test(t) || t.length < 3) continue;
        headline = t; break;
      }
      const img = scope.querySelector('img'); const image = img?.src || null;
      const degree = parseDegreeBadge(scope) ?? (location.pathname.startsWith("/mynetwork/") ? 1 : 2);
      out.push({ url: `https://www.linkedin.com/in/${slug}`, name, headline, image, degree });
    }
    return out;
  }

  async function autoScroll(onTick) {
    let stable = 0, lastH = 0;
    for (let i = 0; i < MAX_PASSES; i++) {
      window.scrollTo(0, document.documentElement.scrollHeight);
      window.dispatchEvent(new Event("scroll"));
      await new Promise((r) => setTimeout(r, SCROLL_PAUSE_MS));
      const h = document.documentElement.scrollHeight;
      const visible = document.querySelectorAll('a[href*="/in/"]').length;
      onTick(visible);
      if (h === lastH) { stable++; if (stable >= 6) return; } else { stable = 0; lastH = h; }
    }
  }

  function makePanel() {
    const wrap = document.createElement("div");
    wrap.style.cssText = "position:fixed;top:88px;right:16px;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;width:320px;background:#fff;box-shadow:0 8px 32px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.06);border-radius:12px;overflow:hidden;";
    wrap.innerHTML = `
      <div style="padding:10px 14px;background:#0a66c2;color:#fff;font-weight:600;">Anker · Sync network</div>
      <div style="padding:14px;font-size:13px;color:#111;">
        <div style="margin-bottom:10px;line-height:1.5;">Scroll the visible cards into view, then send them to Anker.</div>
        <button id="anker-sync-btn" style="width:100%;padding:10px 12px;border:none;border-radius:8px;background:#0a66c2;color:#fff;font-weight:600;font-size:13px;cursor:pointer;">Sync network to Anker</button>
        <div id="anker-sync-msg" style="margin-top:10px;padding:8px 10px;border-radius:8px;background:#f3f4f6;color:#111;font-size:12px;line-height:1.4;display:none;"></div>
      </div>`;
    document.body.appendChild(wrap);
    const btn = wrap.querySelector("#anker-sync-btn");
    const msg = wrap.querySelector("#anker-sync-msg");
    let running = false;
    btn.onclick = async () => {
      if (running) return; running = true; btn.disabled = true; btn.textContent = "Scrolling…";
      msg.style.display = "block"; msg.textContent = "Auto-scrolling to load cards…";
      try {
        await autoScroll((n) => { msg.textContent = `Auto-scrolling · ${n} rows visible`; });
        btn.textContent = "Extracting…";
        const cards = extractCards();
        if (!cards.length) throw new Error("No cards found on this page.");
        btn.textContent = "Sending…";
        let ins = 0, upd = 0;
        for (let i = 0; i < cards.length; i += BATCH_SIZE) {
          const chunk = cards.slice(i, i + BATCH_SIZE);
          const res = await chrome.runtime.sendMessage({ type: "connections_sync", connections: chunk });
          if (res?.error) throw new Error(res.error);
          ins += Number(res?.inserted ?? 0); upd += Number(res?.updated ?? 0);
          msg.textContent = `Sent ${i + chunk.length} / ${cards.length}…`;
        }
        btn.textContent = "Done · run again"; btn.style.background = "#16a34a";
        msg.textContent = `Saved: ${ins} new · ${upd} updated · ${cards.length} total`;
      } catch (e) {
        btn.textContent = "Retry"; btn.style.background = "#dc2626";
        msg.textContent = e?.message || "Capture failed.";
      } finally { btn.disabled = false; running = false; }
    };
  }
  makePanel();
})();
