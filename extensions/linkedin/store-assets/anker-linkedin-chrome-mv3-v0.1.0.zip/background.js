// Anker LinkedIn — background service worker.
// Reads config from chrome.storage.local, adds Authorization: Bearer to
// every request, and forwards to the configured Anker base URL.

const KEYS = { baseUrl: "ankerBaseUrl", token: "ankerToken" };
const DEFAULT_BASE = "https://anker.de";

async function getConfig() {
  const { [KEYS.baseUrl]: baseUrl, [KEYS.token]: token } =
    await chrome.storage.local.get([KEYS.baseUrl, KEYS.token]);
  return { baseUrl: (baseUrl || DEFAULT_BASE).replace(/\/$/, ""), token: token || null };
}

async function ankerFetch(path, init = {}) {
  const { baseUrl, token } = await getConfig();
  if (!token) throw new Error("No token set. Open the popup and paste your Anker token.");
  const headers = { "Content-Type": "application/json", ...(init.headers || {}), Authorization: `Bearer ${token}` };
  return fetch(baseUrl + path, { ...init, headers });
}

async function whoami() {
  try {
    const r = await ankerFetch("/api/extension/whoami", { method: "GET" });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const j = await r.json();
    return { ok: true, userId: j.userId, email: j.email || null };
  } catch (e) { return { ok: false, error: e?.message || "Network error" }; }
}

async function ingestProfile(url, html, degree) {
  try {
    const r = await ankerFetch("/api/extension/ingest", {
      method: "POST",
      body: JSON.stringify({ url, html, degree, source: "chrome-extension" }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: j.error || `HTTP ${r.status}` };
    return j;
  } catch (e) { return { ok: false, error: e?.message || "Network error" }; }
}

async function syncConnections(cards) {
  try {
    const r = await ankerFetch("/api/extension/connections", {
      method: "POST",
      body: JSON.stringify({ connections: cards }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: j.error || `HTTP ${r.status}` };
    return j;
  } catch (e) { return { ok: false, error: e?.message }; }
}

async function syncMutuals(personUrl, mutuals) {
  try {
    const r = await ankerFetch("/api/extension/mutuals", {
      method: "POST",
      body: JSON.stringify({ personUrl, mutuals }),
    });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    return { ok: true };
  } catch (e) { return { ok: false, error: e?.message }; }
}

async function draftByName(args) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(args || {})) if (v) p.set(k, String(v));
  try {
    const r = await ankerFetch(`/api/extension/draft-by-name?${p.toString()}`, { method: "GET" });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return { found: false, error: j.error || `HTTP ${r.status}` };
    return j;
  } catch (e) { return { found: false, error: e?.message }; }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg?.type) {
        case "whoami":            sendResponse(await whoami()); break;
        case "ingest":            sendResponse(await ingestProfile(msg.url, msg.html, msg.degree)); break;
        case "connections_sync":  sendResponse(await syncConnections(msg.connections || [])); break;
        case "syncMutuals":       sendResponse(await syncMutuals(msg.personUrl, msg.mutuals || [])); break;
        case "draftByName":       sendResponse(await draftByName(msg)); break;
        default: sendResponse({ error: `Unknown message type: ${msg?.type}` });
      }
    } catch (e) { sendResponse({ error: e?.message || "Worker error" }); }
  })();
  return true;
});
