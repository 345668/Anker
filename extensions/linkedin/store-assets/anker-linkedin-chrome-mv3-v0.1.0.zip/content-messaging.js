(function () {
  if (window.__ankerMsgMounted) return;
  window.__ankerMsgMounted = true;

  function pickRecipient() {
    // Best-effort: pull the recipient name from the messaging conversation title.
    const el = document.querySelector('[class*="title-bar__title"], [class*="msg-conversation-name"], header h2');
    return (el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function makePanel() {
    const wrap = document.createElement("div");
    wrap.style.cssText = "position:fixed;bottom:16px;right:16px;z-index:2147483647;width:340px;background:#fff;box-shadow:0 8px 32px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.06);border-radius:12px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;overflow:hidden;";
    wrap.innerHTML = `
      <div style="padding:10px 14px;background:#0a66c2;color:#fff;font-weight:600;display:flex;justify-content:space-between;">
        <span>Anker · Outreach assist</span><button id="anker-msg-close" style="background:none;border:none;color:#fff;cursor:pointer;font-size:14px;">×</button>
      </div>
      <div id="anker-msg-body" style="padding:14px;font-size:13px;color:#111;">Detecting recipient…</div>`;
    document.body.appendChild(wrap);
    const body = wrap.querySelector("#anker-msg-body");
    wrap.querySelector("#anker-msg-close").onclick = () => wrap.remove();

    async function refresh() {
      const name = pickRecipient();
      if (!name) { body.textContent = "Open a conversation to load drafts."; return; }
      body.textContent = `Loading drafts for ${name}…`;
      const [firstName, ...rest] = name.split(/\s+/);
      const res = await chrome.runtime.sendMessage({ type: "draftByName", firstName, lastName: rest.join(" ") });
      if (!res?.found) { body.innerHTML = `<div style="color:#6b7280;">No draft found for ${name}. ${res?.hint || ""}</div>`; return; }
      const escape = (s) => (s || "").replace(/</g, "&lt;");
      body.innerHTML = `
        <div style="margin-bottom:8px;font-weight:600;">${escape(res.name || name)}</div>
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.06em;color:#6b7280;margin-bottom:4px;">Subject</div>
        <div style="font-size:12px;background:#f3f4f6;padding:8px;border-radius:6px;margin-bottom:10px;">${escape(res.subject || "—")}</div>
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.06em;color:#6b7280;margin-bottom:4px;">DM</div>
        <div style="font-size:12px;background:#f3f4f6;padding:8px;border-radius:6px;margin-bottom:10px;white-space:pre-wrap;">${escape(res.dm || res.body || "—")}</div>
        <button id="anker-copy-dm" style="width:100%;padding:8px;border:none;border-radius:6px;background:#0a66c2;color:#fff;font-weight:600;cursor:pointer;">Copy DM</button>`;
      body.querySelector("#anker-copy-dm").onclick = () => navigator.clipboard.writeText(res.dm || res.body || "");
    }
    refresh();
    // Refresh every 4s if URL changes (SPA nav).
    let last = location.href;
    setInterval(() => { if (location.href !== last) { last = location.href; refresh(); } }, 4000);
  }
  setTimeout(makePanel, 1200);
})();
