const KEYS = { baseUrl: "ankerBaseUrl", token: "ankerToken", bulkDelayMs: "ankerBulkDelayMs" };
const DEFAULT_BASE = "https://anker.de";

const main = document.getElementById("main");
document.querySelectorAll("nav button").forEach((b) => {
  b.addEventListener("click", () => {
    document.querySelectorAll("nav button").forEach((x) => x.classList.remove("active"));
    b.classList.add("active");
    render(b.dataset.tab);
  });
});

async function loadConfig() {
  const r = await chrome.storage.local.get(Object.values(KEYS));
  return { baseUrl: r[KEYS.baseUrl] || DEFAULT_BASE, token: r[KEYS.token] || "", bulkDelayMs: Number(r[KEYS.bulkDelayMs]) || 3000 };
}

async function render(tab) {
  const cfg = await loadConfig();
  if (tab === "setup") return renderSetup(cfg);
  if (tab === "bulk") return renderBulk(cfg);
  if (tab === "conn") return renderConn(cfg);
}

function renderSetup(cfg) {
  main.innerHTML = `
    <label class="field"><span>Anker base URL</span>
      <input type="text" id="baseUrl" value="${cfg.baseUrl}" placeholder="https://anker.vercel.app"></label>
    <label class="field"><span>Bearer token</span>
      <textarea id="token" rows="2" placeholder="ank_...">${cfg.token}</textarea>
      <p class="hint">Mint at <code>${cfg.baseUrl}/dashboard/settings/extension-tokens</code>. Stored locally only.</p>
    </label>
    <label class="field"><span>Bulk capture delay (ms)</span>
      <input type="number" id="bulkDelay" min="1000" step="500" value="${cfg.bulkDelayMs}"></label>
    <div style="display:flex;gap:8px;">
      <button class="secondary" id="save">Save</button>
      <button class="primary" id="test">Test connection</button>
    </div>
    <div id="result"></div>`;
  document.getElementById("save").onclick = save;
  document.getElementById("test").onclick = async () => { await save(); await test(); };
}

async function save() {
  const patch = {
    [KEYS.baseUrl]: document.getElementById("baseUrl").value.trim() || DEFAULT_BASE,
    [KEYS.token]: document.getElementById("token").value.trim(),
    [KEYS.bulkDelayMs]: String(Math.max(1000, Number(document.getElementById("bulkDelay").value) || 3000)),
  };
  await chrome.storage.local.set(patch);
}

async function test() {
  const r = document.getElementById("result"); r.className = ""; r.textContent = "Testing…";
  const res = await chrome.runtime.sendMessage({ type: "whoami" });
  if (res?.ok) { r.className = "result ok"; r.textContent = `Connected as ${res.email || res.userId}`; }
  else { r.className = "result err"; r.textContent = res?.error || "Token rejected."; }
}

function renderBulk(cfg) {
  main.innerHTML = `
    <label class="field"><span>LinkedIn URLs (one per line)</span>
      <textarea id="urls" rows="6" placeholder="https://www.linkedin.com/in/annewojcicki"></textarea></label>
    <button class="primary" id="go">Capture profile(s)</button>
    <ul id="progress" style="margin-top:10px;padding:0;list-style:none;max-height:220px;overflow:auto;"></ul>`;
  document.getElementById("go").onclick = async () => {
    const raw = document.getElementById("urls").value;
    const urls = raw.split(/[\r\n,]+/).map((s) => s.trim()).filter((s) => /linkedin\.com\/in\//i.test(s));
    if (!urls.length) return;
    const list = document.getElementById("progress"); list.innerHTML = "";
    for (let i = 0; i < urls.length; i++) {
      const li = document.createElement("li"); li.style.padding = "6px 0"; li.style.borderBottom = "1px solid #f3f4f6";
      li.textContent = `⋯ ${urls[i]}`; list.appendChild(li);
      const tab = await chrome.tabs.create({ url: urls[i], active: false });
      await new Promise((res) => {
        const listener = (id, info) => { if (id === tab.id && info.status === "complete") { chrome.tabs.onUpdated.removeListener(listener); res(); } };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); res(); }, 12000);
      });
      await new Promise((r) => setTimeout(r, 800));
      try {
        const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => document.documentElement.outerHTML });
        const html = result;
        const res = await chrome.runtime.sendMessage({ type: "ingest", url: urls[i], html });
        if (res?.ok) li.textContent = `✓ ${urls[i]} — ${res.extracted?.fullName || "saved"}`;
        else if (res?.reason === "no_match") li.textContent = `? ${urls[i]} — ${res.hint || "no CRM match"}`;
        else li.textContent = `✕ ${urls[i]} — ${res?.error || "unexpected"}`;
      } catch (e) { li.textContent = `✕ ${urls[i]} — ${e?.message || "error"}`; }
      try { await chrome.tabs.remove(tab.id); } catch {}
      if (i < urls.length - 1) await new Promise((r) => setTimeout(r, cfg.bulkDelayMs));
    }
  };
}

function renderConn() {
  main.innerHTML = `
    <div style="padding:10px 12px;border-radius:8px;background:#eff6ff;color:#1e3a8a;border:1px solid #dbeafe;font-size:12px;line-height:1.5;margin-bottom:12px;">
      Sync your 1st-degree LinkedIn connections into the Anker Network graph.
    </div>
    <ol style="margin:0 0 12px 18px;padding:0;font-size:12px;color:#374151;line-height:1.6;">
      <li>Click <b>Open My Connections</b>.</li>
      <li>Wait for LinkedIn to render your list.</li>
      <li>The <b>Anker · Sync network</b> panel appears on the right.</li>
      <li>Hit <b>Sync network to Anker</b>.</li>
      <li>Then open <code>/dashboard/network</code> in Anker.</li>
    </ol>
    <button class="primary" style="width:100%;" id="open">Open My Connections</button>`;
  document.getElementById("open").onclick = () => chrome.tabs.create({ url: "https://www.linkedin.com/mynetwork/invite-connections/connections/", active: true });
}

render("setup");
